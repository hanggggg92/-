function setup() {
  createCanvas(710, 710);
  dim = width / 1;
  background(0);
  colorMode(HSB, 500, 100, 100);
  noStroke();
  ellipseMode(RADIUS);
  frameRate(3);
}

function draw() {
  background(0);
  for (let x = 0; x <= width; x += dim) {
    drawGradient(x, height / 2);
  }
}

function drawGradient(x, y) {
  let radius = dim / 2;
  let h = random(0, 360);
  for (let r = radius; r > 0; --r) {
    fill(h, 90, 90);
    ellipse(width / 2, height / 2, r, r);
    h = (h + 1) % 8000;
  }
}